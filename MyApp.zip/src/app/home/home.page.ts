import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  correo: string = '';
  clave: string = '';

  constructor(private navCtrl: NavController) {}

  iniciarSesion() {
    // Obtener la lista de usuarios del localStorage
    let usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');

    // Buscar el usuario con el correo y la clave ingresados
    const usuario = usuarios.find((u: any) => u.correo === this.correo && u.clave === this.clave);

    if (usuario) {
      // Guardar el correo del usuario activo
      localStorage.setItem('usuarioActivo', this.correo);

      // Redirigir a la página de perfil
      this.navCtrl.navigateForward('/perfil');
    } else {
      alert('Correo o clave incorrectos.');
    }
  }
}


