import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage {
  nombre: string = '';
  edad: number | null = null;
  sexo: string = '';
  lugar: string = '';
  correo: string = '';
  clave: string = '';

  constructor(private navCtrl: NavController) {}

  registrarUsuario() {
    if (this.correo && this.clave) {
      const nuevoUsuario = {
        nombre: this.nombre,
        edad: this.edad,
        sexo: this.sexo,
        lugar: this.lugar,
        correo: this.correo,
        clave: this.clave,
      };

      // Obtener la lista de usuarios del localStorage
      let usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');

      // Verificar si el correo ya está registrado
      const existeUsuario = usuarios.find((usuario: any) => usuario.correo === this.correo);
      if (existeUsuario) {
        alert('Este correo ya está registrado.');
        return;
      }

      // Agregar el nuevo usuario a la lista
      usuarios.push(nuevoUsuario);

      // Guardar la lista de usuarios actualizada en localStorage
      localStorage.setItem('usuarios', JSON.stringify(usuarios));

      // Guardar el correo del usuario activo
      localStorage.setItem('usuarioActivo', this.correo);

      alert('Registro exitoso.');

      // Redirigir a la página de perfil
      this.navCtrl.navigateForward('/perfil');
    } else {
      alert('Por favor, completa todos los campos.');
    }
  }
}
