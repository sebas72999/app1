import { Component } from '@angular/core';

@Component({
  selector: 'app-recover-password',
  templateUrl: './recover-password.page.html',
  styleUrls: ['./recover-password.page.scss'],
})
export class RecoverPasswordPage {
  correo: string = '';
  successMsg: string = '';
  errorMsg: string = '';

  constructor() { }

  recuperarContrasena() {
    if (this.correo) {
      // Simulación de solicitud para recuperar la contraseña
      this.successMsg = 'Se ha enviado un enlace de recuperación a su correo.';
      this.errorMsg = '';
    } else {
      this.errorMsg = 'Por favor ingrese un correo válido.';
      this.successMsg = '';
    }
  }
}

