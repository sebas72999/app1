import { Component } from '@angular/core';

@Component({
  selector: 'app-yo-te-llevo',
  templateUrl: './yo-te-llevo.page.html',
  styleUrls: ['./yo-te-llevo.page.scss'],
})
export class YoTeLlevoPage {
  constructor() {}
}
